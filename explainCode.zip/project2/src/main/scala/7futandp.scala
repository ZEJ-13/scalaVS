/*import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

object fndp{
  def main(args: Array[String]): Unit = {
    // Define a Future that will execute an expensive computation asynchronously
    val future = Future {
      Thread.sleep(5000) // Simulate an expensive computation by sleeping for 5 seconds
      42 // Return the result of the computation
    }

    // Print a message to indicate that the future is being executed
    println("Starting future...")

    // Use the 'onComplete' method to register a callback function to be called when the future completes
    future.onComplete {
      case scala.util.Success(result) => // If the future completes successfully, print the result
        println(s"Future completed successfully with result: $result")
      case scala.util.Failure(ex) => // If the future fails, print the exception
        println(s"Future failed with exception: $ex")
    }

    // Print a message to indicate that the future has been registered
    println("Future registered!")
    
    // Sleep for 6 seconds to allow the future to complete
    Thread.sleep(6000)

    // Print a message to indicate that the program has completed
    println("Program completed!")
  }
}
*/
import scala.concurrent.{Future, Promise}
import scala.concurrent.ExecutionContext.Implicits.global

object Factorial {
  def calculateFactorial(n: Int): Future[BigInt] = {
    val p = Promise[BigInt]()
    Future {
      var result = BigInt(1)
      for (i <- 1 to n) {
        result *= i
      }
      p.success(result)
    }
    p.future
  }
}

object fandp {
  def main(args: Array[String]): Unit = {
    val f = Factorial.calculateFactorial(10)
    f.foreach(result => println(s"Result: $result"))
  }
}
