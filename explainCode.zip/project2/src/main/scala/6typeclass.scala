object tClass {
  def main(args: Array[String]): Unit = {

    // Define the Printable trait, which specifies a single method `format`.
    trait Printable[T] {
      def format(value: T): String
    }

    // Define instances of Printable for String and Int using implicit values.
    object PrintableInstances {
      implicit val printableString: Printable[String] = new Printable[String] {
        def format(value: String): String = value
      }

      implicit val printableInt: Printable[Int] = new Printable[Int] {
        def format(value: Int): String = value.toString
      }
    }

    // Define syntax to allow for `format` to be called directly on a value of any type.
    object PrintableSyntax {
      implicit class PrintableOps[T](value: T) {
        def format(implicit printable: Printable[T]): String =
          printable.format(value)
      }
    }

    // Import the Printable instances and syntax into the current scope.
    import PrintableInstances._
    import PrintableSyntax._

    // Define a function that takes a value of any type and a Printable instance for that type,
    // and prints the formatted value to the console.
    def printFormatted[T](value: T)(implicit printable: Printable[T]): Unit =
      println(printable.format(value))

    // Call `printFormatted` with a String and an Int.
    printFormatted("Hello, World!")
    printFormatted(42)
  }
}
