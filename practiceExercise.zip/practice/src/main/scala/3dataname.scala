
object NameLengths {
  def main(args: Array[String]): Unit = {
    val names = List("Alice", "Bob", "Charlie", "Bob", "David", "Alice")
    val distinctNames = names.<?> // remove duplicates from the list

    val nameLengths = distinctNames.<?> { name =>
      // TODO: replace the question marks to calculate the length of each name
    }

    val nameLengthMap = nameLengths.<?> { case (name, length) =>
      //TODO: replace the question marks to create a tuple of (name, length) and add it to a map
    }

    println(nameLengthMap)
  }
}

