// Define a trait named `Shape` with an abstract method `area`
trait Shape {
  def area(): Double
}

// Define a class named `Circle` that extends `Shape`
// and has a private field `radius` of type `Double`
// and a constructor that takes a `radius` parameter
// Implement the `area` method by calculating the area of the circle
// Formula: pi * radius^2
class Circle(?): Shape {
  override def area: Double = {
    // calculate the area of the circle
  }
}

// Define a class named `Rectangle` that extends `Shape`
// and has private fields `width` and `height` of type `Double`
// and a constructor that takes `width` and `height` parameters
// Implement the `area` method by calculating the area of the rectangle
// Formula: width * height
class Rectangle(?): Shape {
  override def area: Double = {
    // calculate the area of the rectangle
  }
}

// Define a function named `printArea` that takes a `Shape` parameter
// and prints the area of the shape
def printArea(shape: Shape): Unit = {
  println(s"The area of the shape is ${shape.area}")
}

// Create a circle object with radius 2.5 and print its area
val circle = new Circle(?)
printArea(circle)

// Create a rectangle object with width 3.0 and height 4.0 and print its area
val rectangle = new Rectangle(?)
printArea(rectangle)
