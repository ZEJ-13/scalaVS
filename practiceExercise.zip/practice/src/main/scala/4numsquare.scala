import scala.collection.immutable
/*
Using the data structures that we just learned (list, set, map, stream, tuple, and option), 
create a program that takes in a list of numbers as input, removes any duplicates from the list, 
squares each remaining number, and then returns a map where the original numbers are the keys
and the squared numbers are the values. 
Use options to handle any null values that might arise in the input list or the map
*/
object NumberSquarer {
  def main(args: Array[String]): Unit = {
    // Prompt the user to input a list of numbers
    println("Enter a list of numbers separated by spaces:")
    val inputList = scala.io.StdIn.readLine().split(" ").toList.flatMap(s => Option(s.toDouble))

    // Remove duplicates from the list
    val distinctList = inputList.distinct

    // TODO: Square each number in the list and create a map

    // Print the resulting map
    println("Original -> Squared:")
    squaredMap.foreach { case (k, v) => println(s"$k -> $v") }
  }
}
