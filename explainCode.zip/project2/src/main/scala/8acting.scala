// Importing classes from the Akka actor library
import akka.actor.{Actor, ActorSystem, Props}

// Definition of a case class for a greeting message
case class Greet(name: String)

// Definition of an actor that handles greeting messages
class GreetingActor extends Actor {
  override def receive: Receive = {
    case Greet(name) => println(s"Hello, $name!")
  }
}

// Main object that creates the actor system and sends greeting messages
object ActorDemo extends App {
  // Creating an actor system with the name "actor-demo"
  val system = ActorSystem("actor-demo")
  // Instantiating an actor of type GreetingActor with the name "greeting-actor"
  val greetingActor = system.actorOf(Props[GreetingActor](), "greeting-actor")
  
  // Sending greeting messages to the greetingActor
  greetingActor ! Greet("Alice")
  greetingActor ! Greet("Bob")
  
  // Shutting down the actor system
  system.terminate()
}
