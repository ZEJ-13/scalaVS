object tClassExercise {
  def main(args: Array[String]): Unit = {

    // Define the JSON type class, which specifies a single method `toJson`.
    trait JSON[T] {
      def toJson(value: T): String
    }

    // Define instances of JSON for String and Int using implicit values.
    object JSONInstances {
      // TODO: Define an implicit JSON instance for String that returns the string value surrounded by quotes.
      implicit val jsonString: JSON[String] = new JSON[String] {
        def toJson(value: String): String = "\"" + value + "\""
      }

      // TODO: Define an implicit JSON instance for Int that returns the integer value as a string.
      implicit val jsonInt: JSON[Int] = new JSON[Int] {
        def toJson(value: Int): String = value.toString
      }
    }

    // Define syntax to allow for `toJson` to be called directly on a value of any type.
    object JSONSyntax {
      // TODO: Define an implicit class `JSONOps` that takes a value of type `T` and provides a `toJson` method.
      implicit class JSONOps[T](value: T) {
        def toJson(implicit json: JSON[T]): String = json.toJson(value)
      }
    }

    // Import the JSON instances and syntax into the current scope.
    // TODO: Import the JSONInstances and JSONSyntax objects.
    import JSONInstances._
    import JSONSyntax._

    // Define a function that takes a value of any type and a JSON instance for that type,
    // and prints the JSON representation of the value to the console.
    def printJson[T](value: T)(implicit json: JSON[T]): Unit =
      println(json.toJson(value))

    // Call `printJson` with a String and an Int.
    printJson("Hello, World!")
    printJson(42)
  }
}

/*object Exercise {
  def main(args: Array[String]): Unit = {

    // Define the JSON trait, which specifies a single method `toJson`.
    trait JSON[T] {
      def toJson(value: T): String
    }

    // Define instances of JSON for Boolean and Double using implicit values.
    object JSONInstances {
      implicit val jsonBoolean: JSON[Boolean] = new JSON[Boolean] {
        def toJson(value: Boolean): String = value.toString
      }

      implicit val jsonDouble: JSON[Double] = new JSON[Double] {
        def toJson(value: Double): String = value.toString
      }
    }

    // Define syntax to allow for `toJson` to be called directly on a value of any type.
    object JSONSyntax {
      implicit class JSONOps[T](value: T) {
        def toJson(implicit json: JSON[T]): String =
          json.toJson(value)
      }
    }

    // Import the JSON instances and syntax into the current scope.
    import JSONInstances._
    import JSONSyntax._

    // Define a function that takes a value of any type and a JSON instance for that type,
    // and prints the JSON representation of the value to the console.
    def printJson[T](value: T)(implicit json: JSON[T]): Unit =
      println(json.toJson(value))

    // Call `printJson` with a Boolean and a Double.
    printJson(true)
    printJson(3.14159)
  }
}
*/
// Define an object called "HelloWorld"
/*object HelloWorld {

  // Define a method called "main" that takes an array of strings as input and returns "Unit" (i.e., no useful value)
  def main(args: Array[String]): Unit = {
    
    // Print the string "Hello, world!" to the console
    println("Hello, world!")
  }
}


class human(var name: String, var age: Int) {
  // Primary constructor
  println("Primary constructor called")

  // Auxiliary constructor with only name parameter
  def this(name: String) = {
    this(name, 0) // Calls primary constructor with default age parameter value
    println("Auxiliary constructor 1 called")
  }

  // Auxiliary constructor with only age parameter
  def this(age: Int) = {
    this("", age) // Calls primary constructor with default name parameter value
    println("Auxiliary constructor 2 called")
  }

  // Auxiliary constructor with no parameters
  def this() = {
    this("", 0) // Calls primary constructor with default parameter values
    println("Auxiliary constructor 3 called")
  }
}

object humanity {
  def main(args: Array[String]): Unit = {
    // Creating instances of Person class using different constructors
    val person1 = new human("Alice", 25) // Uses primary constructor
    val person2 = new human("Bob") // Uses auxiliary constructor 1
    val person3 = new human(30) // Uses auxiliary constructor 2
    val person4 = new human() // Uses auxiliary constructor 3
  }
}

*/