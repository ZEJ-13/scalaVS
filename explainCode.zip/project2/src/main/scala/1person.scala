/* 
-Call the greet method on the Person object to print out the greeting to the console but add 10 years to the age.
-use .copy, you're going to create another person instance based on the last but adding 10 years
-Run the Main object to see the greeting message printed to the console.
*/

// Define a case class for a Person that takes a name and age as parameters
case class Person(name: String, age: Int) {
  // Define a method that prints a greeting message
  def greet(): Unit = {
    println(s"Hello, my name is $name and I'm $age years old.")
  }
}

object Main {
  def main(args: Array[String]): Unit = {
    // new instance of the Person class with the name "Alice" and age 30
    val person = Person("Alice", 30)
    // Call the greet method on the Person instance to print a greeting message with the age
    person.greet()
  }
}
