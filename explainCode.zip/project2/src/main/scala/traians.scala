object CollectionP {
  def main(args: Array[String]): Unit = {
    val numbers = List(1, 2, 3, 4, 5)

    // 1. Use map to create a new list with each number doubled
    val doubled = numbers.map(_ * 2)

    // 2. Use filter to create a new list with only the even numbers
    val evens = numbers.filter(_ % 2 == 0)

    // 3. Use reduce to calculate the sum of all the numbers
    val sum = numbers.reduce(_ + _)

    // 4. Define a function called "multiplyBy" that takes an integer argument "n" and returns
    // a closure that multiplies its argument by "n"
    def multiplyBy(n: Int): Int => Int = (x: Int) => x * n

    // 5. Use currying to define a function called "add" that takes two integers as arguments
    // and returns their sum
    def add(a: Int)(b: Int): Int = a + b

    // 6. Use partial function application to create a new function called "addTwo" that adds 2 to
    // its argument
    val addTwo = add(2) _

    // Test your functions
    println(doubled)
    println(evens)
    println(sum)
    println(multiplyBy(3)(5))
    println(add(3)(5))
    println(addTwo((3)))
  }
}


/*// Define a trait that represents a shape
trait Shape {
  // Define an abstract method to calculate the area of the shape
  def area(): Double
}

// Define a class to represent a rectangle, which extends the Shape trait
class Rectangle(val width: Double, val height: Double) extends Shape {
  // Implement the area method for rectangles
  def area(): Double = width * height
}

// Define a class to represent a circle, which extends the Shape trait
class Circle(val radius: Double) extends Shape {
  // Implement the area method for circles
  def area(): Double = math.Pi * radius * radius
}

object ShapeTest {
  def main(args: Array[String]): Unit = {
    // Create a rectangle object and call its area method
    val rect = new Rectangle(5, 10)
    val rectArea = rect.area()
    println(s"The area of the rectangle is $rectArea")

    // Create a circle object and call its area method
    val circle = new Circle(5)
    val circleArea = circle.area()
    println(s"The area of the circle is $circleArea")
  }
}*/

/*class Person(name: String, age: Int) {
  def greet(): Unit = {
    println(s"Hello, my name is $name and I'm $age years old.")
  }
}

object Main {
  def main(args: Array[String]): Unit = {
    val person = new Person("Alice", 30) //Try changing whatever; play around
    //one line right here for the exercise
    //TODO: Create a new Person instance, but with an age 10 years older
    person.greet()
  }
}*/

/*object NameLengths {
  def main(args: Array[String]): Unit = {
    val names = List("Alice", "Bob", "Charlie", "Bob", "David", "Alice")
    val distinctNames = names.distinct // remove duplicates from the list

    val nameLengths = distinctNames.map(name => (name, name.length)) // calculate the length of each name

    val nameLengthMap = nameLengths.toMap // create a map from the name-length pairs

    println(nameLengthMap)
  }
}

// Define a trait called Animal with a single abstract method called speak that returns a String
trait Animal {
  def speak: String
}

// Define a class called Dog that extends Animal and implements the speak method to return "Woof!"
class Dog extends Animal {
  override def speak: String = "Woof!"
}

// Define a class called Cat that extends Animal and implements the speak method to return "Meow!"
class Cat extends Animal {
  override def speak: String = "Meow!"
}

// Define an object called anima with a main method that creates instances of Dog and Cat, and prompts the user to create a new animal
object anima {
  def main(args: Array[String]): Unit = {
    //TODO: create instance of dog and cat
    val dog = new Dog
    val cat = new Cat

    println(dog.speak) // Print the sound of the dog
    println(cat.speak) // Print the sound of the cat

    // Prompt the user to enter a new animal class and its sound, and print the sound of the new animal
    println("Enter the name of an animal class (e.g. Cow): ")
    val animalClassName = scala.io.StdIn.readLine()

    // Define a new animal class based on the user input
    class NewAnimal extends Animal {
      println(s"Enter the sound of the $animalClassName (e.g. Moo): ")
      //Based on prev readLine, how do you enter the new sound of animal
      val animalSound = scala.io.StdIn.readLine()

      override def speak: String = animalSound
    }

    // Create an instance of the new animal class and print its sound
    val newAnimal = new NewAnimal
    println(s"The $animalClassName says ${newAnimal.speak}")
  }
}*/
