object CollectionProcessing {
  def main(args: Array[String]): Unit = {
    val numbers = List(1, 2, 3, 4, 5)

    // 1. Use map to create a new list with each number doubled
    val doubled = numbers.<?> // replace the question marks

    // 2. Use filter to create a new list with only the even numbers
    val evens = numbers.<?> // replace the question marks

    // 3. Use reduce to calculate the sum of all the numbers
    val sum = numbers.<?> // replace the question marks

    // 4. Define a function called "multiplyBy" that takes an integer argument "n" and returns
    // a closure that multiplies its argument by "n"
    def multiplyBy(n: Int): <?> = {
      // replace the question marks
    }

    // 5. Use currying to define a function called "add" that takes two integers as arguments
    // and returns their sum
    def add = <?> // replace the question marks

    // 6. Use partial function application to create a new function called "addTwo" that adds 2 to
    // its argument
    val addTwo = <?> // replace the question marks

    // Test your functions
    println(doubled)
    println(evens)
    println(sum)
    println(multiplyBy(3)(5))
    println(add(3)(5))
    println(addTwo(3))
  }
}
