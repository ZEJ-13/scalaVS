object CollectionProcessing {
  def main(args: Array[String]): Unit = {
    val numbers = List(1, 2, 3, 4, 5)

    // Using map and filter with anonymous functions
    val doubledNumbers = numbers.map(_ * 2)
    val evenNumbers = numbers.filter(_ % 2 == 0)

    println(doubledNumbers) // Output: List(2, 4, 6, 8, 10)
    println(evenNumbers) // Output: List(2, 4)

    // Using a closure to filter by a threshold value
    val threshold = 3
    val aboveThreshold = numbers.filter(_ > threshold)

    println(aboveThreshold) // Output: List(4, 5)

    // Currying and partial function application
    def add(a: Int, b: Int): Int = a + b
    val addTwo = add(2, _: Int)
    val curriedAdd = (a: Int) => (b: Int) => a + b

    println(addTwo(3)) // Output: 5
    println(curriedAdd(2)(3)) // Output: 5
  }
}