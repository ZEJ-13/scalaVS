/* 
-Call the greet method on the Person object to print out the greeting to the console but add 10 years to the age.
-use .copy, you're going to create another person instance based on the last but adding 10 years
https://www.educative.io/answers/what-is-copy-in-scala
-Run the Main object to see the greeting message printed to the console.
*/

class Person(name: String, age: Int) {
  def greet(): Unit = {
    println(s"Hello, my name is $name and I'm $age years old.")
  }
}

object Main {
  def main(args: Array[String]): Unit = {
    val person = new Person(?, ?) //Try changing the ?; play around
    //TODO: Create a new Person instance, but with an age 10 years older
    ?.greet()
  }
}

