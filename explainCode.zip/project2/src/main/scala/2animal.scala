// Define a trait called Animal with a single abstract method called speak that returns a String
trait Animal {
  def speak: String
}

// Define a class called Dog that extends Animal and implements the speak method to return "Woof!"
class Dog extends Animal {
  override def speak: String = "Woof!"
}

// Define a class called Cat that extends Animal and implements the speak method to return "Meow!"
class Cat extends Animal {
  override def speak: String = "Meow!"
}

// Define an object called animals with a main method that creates instances of Dog and Cat, and prints their respective sounds
object animals {
  def main(args: Array[String]): Unit = {
    val dog = new Dog
    val cat = new Cat

    println(dog.speak) // Print the sound of the dog
    println(cat.speak) // Print the sound of the cat
  }
}
