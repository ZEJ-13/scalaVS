object tClassExercise {
  def main(args: Array[String]): Unit = {

    // Define the JSON type class, which specifies a single method `toJson`.
    trait JSON[T] {
      def toJson(value: T): String
    }

    // Define instances of JSON for String and Int using implicit values.
    object JSONInstances {
      // TODO: Define an implicit JSON instance for String that returns the string value surrounded by quotes.
      implicit val jsonString: JSON[String] = new JSON[String] {
        def toJson(value: String): String = "\"" + value + "\""
      }

      // TODO: Define an implicit JSON instance for Int that returns the integer value as a string.
      implicit val jsonInt: JSON[Int] = new JSON[Int] {
        def toJson(value: Int): String = value.toString
      }
    }

    // Define syntax to allow for `toJson` to be called directly on a value of any type.
    object JSONSyntax {
      // TODO: Define an implicit class `JSONOps` that takes a value of type `T` and provides a `toJson` method.
      implicit class JSONOps[T](value: T) {
        def toJson(implicit json: JSON[T]): String = json.toJson(value)
      }
    }

    // Import the JSON instances and syntax into the current scope.
    // TODO: Import the JSONInstances and JSONSyntax objects.
    import JSONInstances._
    import JSONSyntax._

    // Define a function that takes a value of any type and a JSON instance for that type,
    // and prints the JSON representation of the value to the console.
    def printJson[T](value: T)(implicit json: JSON[T]): Unit =
      println(json.toJson(value))

    // Call `printJson` with a String and an Int.
    printJson("Hello, World!")
    printJson(42)
  }
}
