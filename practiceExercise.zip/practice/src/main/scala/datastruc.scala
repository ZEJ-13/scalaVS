object DataStructures {
  def main(args: Array[String]): Unit = {
    // List
    val list = List(1, 2, 3, 4)
    println(s"List: $list")
    println("A List is an ordered collection of elements. It is created using the List class.")
    println("List Example:")
    println("val list = List(1, 2, 3, 4)")

    // Set
    val set = Set(1, 2, 2, 3, 4, 4, 4)
    println(s"\nSet: $set")
    println("A Set is an unordered collection of unique elements. It is created using the Set class.")
    println("Set Example:")
    println("val set = Set(1, 2, 2, 3, 4, 4, 4)")

    // Map
    val map = Map("a" -> 1, "b" -> 2, "c" -> 3)
    println(s"\nMap: $map")
    println("A Map is a collection of key-value pairs. It is created using the Map class.")
    println("Map Example:")
    println("""val map = Map("a" -> 1, "b" -> 2, "c" -> 3)""")

    // Stream
    val stream = Stream(1, 2, 3, 4).map(_ * 2)
    println(s"\nStream: ${stream.toList}")
    println("A Stream is a lazily-evaluated sequence of elements. It is created using the Stream class.")
    println("Stream Example:")
    println("val stream = Stream(1, 2, 3, 4).map(_ * 2)")

    // Tuple
    val tuple = ("John", 30)
    println(s"\nTuple: $tuple")
    println("A Tuple is an ordered collection of elements of different types. It is created using parentheses.")
    println("Tuple Example:")
    println("""val tuple = ("John", 30)""")

    // Option
    val option1 = Option("Hello")
    val option2 = Option(null)
    println(s"\nOption1: $option1")
    println(s"Option2: $option2")
    println("An Option is a container for a potentially missing value. It is created using the Option class.")
    println("Option Example:")
    println("val option1 = Option(\"Hello\")")
    println("val option2 = Option(null)")
  }
}
