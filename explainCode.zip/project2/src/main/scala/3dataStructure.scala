object DataStructures {
  def main(args: Array[String]): Unit = {
    // List
    val list = List(1, 2, 3, 4)
    println(s"List: $list")

    // Set
    val set = Set(1, 2, 2, 3, 4, 4, 4)
    println(s"Set: $set")

    // Map
    val map = Map("a" -> 1, "b" -> 2, "c" -> 3)
    println(s"Map: $map")

    // Stream
    val stream = Stream(1, 2, 3, 4).map(_ * 2)
    println(s"Stream: ${stream.toList}")

    // Tuple
    val tuple = ("John", 30)
    println(s"Tuple: $tuple")

    // Option
    val option1 = Option("Hello")
    val option2 = Option(null)
    println(s"Option1: $option1")
    println(s"Option2: $option2")
  }
}
